package telran.library.service.interfaces;

public interface ILogger {

}
