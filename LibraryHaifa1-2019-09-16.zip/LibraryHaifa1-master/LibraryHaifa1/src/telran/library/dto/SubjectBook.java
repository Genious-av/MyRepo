package telran.library.dto;

public enum SubjectBook {
LITERATURE, EDUCATION, SCIENCE 
}
